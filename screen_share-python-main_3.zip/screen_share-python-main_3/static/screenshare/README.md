# About
Super-simple screen sharing with nothing but Python and Flask.

# Necessary libraries:

    pip install pyscreenshot
    pip install flask
    pip install pillow

# Install

    ./scripts/install

# Running

    ./scripts/run

Then visit [http://localhost:5000](http://localhost:5000).

# Disclaimer

Tested with Ubuntu 12.04. The pyscreenshot library may not work on your system!
